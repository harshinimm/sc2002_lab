abstract class Shape2D implements Shape {
    public abstract double area();
}
