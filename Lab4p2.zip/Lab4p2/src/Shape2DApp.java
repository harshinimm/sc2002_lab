import java.util.Scanner;
import java.util.ArrayList;

public class Shape2DApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Shape2D> shapes = new ArrayList<>();

        System.out.print("Enter the number of 2D shapes: ");
        int numShapes = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numShapes; i++) {
            System.out.println("Choose a shape: 1. Circle, 2. Rectangle, 3. Triangle");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter radius: ");
                    double radius = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    shapes.add(new Circle(radius));
                    break;
                case 2:
                    System.out.print("Enter length: ");
                    double length = scanner.nextDouble();
                    System.out.print("Enter width: ");
                    double width = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    shapes.add(new Rectangle(length, width));
                    break;
                case 3:
                    System.out.print("Enter base: ");
                    double base = scanner.nextDouble();
                    System.out.print("Enter height: ");
                    double height = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    shapes.add(new Triangle(base, height));
                    break;
                default:
                    System.out.println("Invalid choice. Skipping...");
            }
        }

        double totalArea = 0;
        System.out.println("\nAreas of individual shapes:");
        for (Shape2D shape : shapes) {
            double area = shape.area();
            System.out.println(shape.getClass().getSimpleName() + " Area: " + area);
            totalArea += area;
        }

        System.out.println("\nTotal 2D surface area: " + totalArea);
        scanner.close();
    }
}
