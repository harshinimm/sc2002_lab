public class PlaneSeat {
    private final int seatId;
    private boolean assigned;
    private int customerId;


    public PlaneSeat(int seatId) {
        this.seatId = seatId;
        this.assigned = false;  // Seat starts unassigned
        this.customerId = 0;  // No customer assigned initially
    }


    public int getSeatID() {
        return this.seatId;
    }


    public int getCustomerId() {
        return this.customerId;
    }

    public boolean isOccupied() {
        return this.assigned;
    }

    public void assign(int custId) {
        if (!assigned) {
            this.assigned = true;
            this.customerId = custId;
            System.out.println("The seat has been assigned to customer ID: " + custId);
        } else {
            System.out.println("The seat is already occupied by customer ID: " + this.customerId);
        }
    }
    public void unAssign() {
        if (assigned) {
            this.assigned = false;
            this.customerId = 0;
            System.out.println("The seat has been unassigned.");
        } else {
            System.out.println("The seat is already unassigned.");
        }
    }
}
