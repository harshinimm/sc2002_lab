package mysecondconversion;

import java.util.Scanner;

public class P3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter starting value:");
        int start = sc.nextInt();

        System.out.println("Enter increment:");
        int inc = sc.nextInt();

        System.out.println("Enter ending value:");
        int end = sc.nextInt();

        if (start < 0 || end <= 0 || start > end) {
            System.out.println("Error input!!");
        }



        System.out.println("US$      S$");
        System.out.println("-------------");
        int i=start;
        while (i<=end) {
            System.out.println(i + "     " + (i * 1.82));
            i += inc;
        }

        sc.close();


        }

}

