import java.util.Scanner;
import java.util.ArrayList;

public class Shape3DApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Shape3D> shapes = new ArrayList<>();

        System.out.print("Enter the number of 3D shapes: ");
        int numShapes = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        for (int i = 0; i < numShapes; i++) {
            System.out.println("Choose a shape: 1. Sphere, 2. Cuboid, 3. Cone, 4. Cylinder");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter radius: ");
                    double radius = scanner.nextDouble();
                    scanner.nextLine();
                    shapes.add(new Sphere(radius));
                    break;
                case 2:
                    System.out.print("Enter length: ");
                    double length = scanner.nextDouble();
                    System.out.print("Enter width: ");
                    double width = scanner.nextDouble();
                    System.out.print("Enter height: ");
                    double height = scanner.nextDouble();
                    scanner.nextLine();
                    shapes.add(new Cuboid(length, width, height));
                    break;
                case 3:
                    System.out.print("Enter radius: ");
                    radius = scanner.nextDouble();
                    System.out.print("Enter height: ");
                    height = scanner.nextDouble();
                    scanner.nextLine();
                    shapes.add(new Cone(radius, height));
                    break;
                case 4:
                    System.out.print("Enter radius: ");
                    radius = scanner.nextDouble();
                    System.out.print("Enter height: ");
                    height = scanner.nextDouble();
                    scanner.nextLine();
                    shapes.add(new Cylinder(radius, height));
                    break;
                default:
                    System.out.println("Invalid choice. Skipping...");
            }
        }

        double totalSurfaceArea = 0;
        System.out.println("\nSurface area of individual shapes:");
        for (Shape3D shape : shapes) {
            double area = shape.surfaceArea();
            System.out.println(shape.getClass().getSimpleName() + " Surface Area: " + area);
            totalSurfaceArea += area;
        }

        System.out.println("\nTotal 3D surface area: " + totalSurfaceArea);
        scanner.close();
    }
}
