class Cuboid extends Shape3D {
    private double length, width, height;

    public Cuboid(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    public double surfaceArea() {
        return 2 * (length * width + width * height + height * length);
    }
}

