import java.util.Scanner;

public class P4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter rows: ");
        int rows = scanner.nextInt();
        if (rows <= 0) {
            System.out.println("Error input!!");
        } else {
            for (int i = 1; i <= rows; i++) {
                for (int j = 0; j < i; j++) {
                    if (j % 2 == 0) {
                        System.out.print("AA");
                    } else {
                        System.out.print("BB");
                    }
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
