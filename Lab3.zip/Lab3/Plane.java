import java.util.Arrays;
import java.util.Comparator;

public class Plane {
    private PlaneSeat[] seats;
    private int numEmptySeat;

    public Plane() {
        seats = new PlaneSeat[12];  // Assuming 12 seats in the plane
        numEmptySeat = 12;

        for (int i = 0; i < 12; i++) {
            seats[i] = new PlaneSeat(i + 1); // Seat IDs 1 to 12
        }
    }


    private PlaneSeat[] sortSeatsByCustomerID() {
        PlaneSeat[] sortedSeats = Arrays.copyOf(seats, seats.length);
        Arrays.sort(sortedSeats, new Comparator<PlaneSeat>() {
            public int compare(PlaneSeat s1, PlaneSeat s2) {
                return Integer.compare(s1.getCustomerId(), s2.getCustomerId());
            }
        });
        return sortedSeats;
    }

    public void showNumEmptySeats() {
        System.out.println("The number of empty seats are: " + numEmptySeat);
    }

    public void showEmptySeats() {
        System.out.println("Empty Seats:");
        for (PlaneSeat seat : seats) {
            if (!seat.isOccupied()) {
                System.out.println("Seat ID: " + seat.getSeatID());
            }
        }
    }

    public void showAssignedSeats(boolean bySeatId) {
        if (bySeatId) {
            Arrays.sort(seats, (a, b) -> Integer.compare(a.getSeatID(), b.getSeatID()));
        } else {
            Arrays.sort(seats, (a, b) -> Integer.compare(a.getCustomerId(), b.getCustomerId()));
        }

        System.out.println("Assigned seats:");
        for (PlaneSeat seat : seats) {
            if (seat.isOccupied()) {
                System.out.println("Seat ID: " + seat.getSeatID() + ", Customer ID: " + seat.getCustomerId());
            }
        }
    }

    public void assignSeat(int seatId, int custId) {
        if (seatId < 1 || seatId > 12) {
            System.out.println("Invalid seat ID.");
            return;
        }

        PlaneSeat seat = seats[seatId - 1];
        if (!seat.isOccupied()) {
            seat.assign(custId);
            numEmptySeat--;
        } else {
            System.out.println("Seat " + seatId + " is already occupied.");
        }
    }

    public void unAssignSeat(int seatId) {
        if (seatId < 1 || seatId > 12) {
            System.out.println("Invalid seat ID.");
            return;
        }

        PlaneSeat seat = seats[seatId - 1];
        if (seat.isOccupied()) {
            seat.unAssign();
            numEmptySeat++;
        } else {
            System.out.println("Seat " + seatId + " is already unassigned.");
        }
    }
}

