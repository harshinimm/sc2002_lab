import java.util.Scanner;

public class PlaneApp {

    public static void main(String[] args) {
        int choice;
        int seat_id, cust_id;
        Plane assign = new Plane();

        Scanner sc = new Scanner(System.in);

        do {
            // Display the menu
            System.out.println("1: Show the number of empty seats");
            System.out.println("2: Show the list of empty seats");
            System.out.println("3: Show the list of customers together with their seat numbers in the order of the seat numbers");
            System.out.println("4: Show the list of customers together with their seat numbers in the order of the customer ID");
            System.out.println("5: Assign a customer to a seat");
            System.out.println("6: Remove a seat assignment");
            System.out.println("7: Quit");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    assign.showNumEmptySeats();
                    break;
                case 2:
                    assign.showEmptySeats();
                    break;
                case 3:
                    assign.showAssignedSeats(true);
                    break;
                case 4:
                    assign.showAssignedSeats(false);
                    break;
                case 5:
                    System.out.println("Assigning Seat ..");
                    System.out.println("Please enter SeatID:");
                    seat_id = sc.nextInt();
                    System.out.println("Please enter CustomerID:");
                    cust_id = sc.nextInt();
                    if ((seat_id < 1) || (seat_id > 12)) {
                        System.out.println("Seat ID out of range!");
                    } else {
                        assign.assignSeat(seat_id, cust_id);
                    }
                    break;
                case 6:
                    System.out.println("Enter SeatID to unassign customer from:");
                    seat_id = sc.nextInt();
                    assign.unAssignSeat(seat_id);
                    break;
                case 7:
                    System.out.println("Program terminating ….");
                    break;
                default:
                    System.out.println("Invalid Option! Please choose a valid option.");
                    break;
            }

        } while (choice != 7);
    }
}

